import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class Salesforce_Dashbord {
	WebDriver driver;
	@BeforeClass
	public void innitObjects() {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\Dell-\\Downloads\\chromedriver_win32\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("https://www.salesforce.com/");
	}
	@Test
	public void TestLogin() {
		driver.findElement(By.xpath("/html/body/header/div[2]/div/div[3]/div/div/div/nav/div[1]/div/div[3]/div[1]/div[6]/div/a")).click();
		driver.findElement(By.xpath("//*[@id='username']")).sendKeys("Akdhst");;
	}
}
