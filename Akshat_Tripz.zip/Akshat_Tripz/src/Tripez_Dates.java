import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class Tripez_Dates {
	WebDriver driver;
	@BeforeClass
	public void innitObjects() {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\Dell-\\Downloads\\chromedriver_win32\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("https://www.tripeasy.com/");
		driver.manage().window().maximize();
	}
	@Test
	public void TestLogin() {
		try {
		driver.findElement(By.xpath("//*[@id='radioOneWayTrip']")).click();
		driver.findElement(By.xpath("//*[@id='SearchViewModels_airTravelComponentSubRequestRoundTrip_DepartureAirport']")).sendKeys("Mumbai");
		driver.findElement(By.xpath("//*[@id='SearchViewModels_airTravelComponentSubRequestRoundTrip_ArrivalAirport']")).sendKeys("Pune");
		driver.findElement(By.xpath("//*[@id='datePickerDepart']")).click();
		driver.findElement(By.xpath("//*[@id='divMain']/div/div[2]/table/tbody/tr[3]/td[4]")).click();
		driver.findElement(By.xpath("//*[@id='btnSearchTravel']")).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.navigate().back();
		Thread.sleep(5000);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	@AfterClass
	public void cleanTask() {
		driver.close();
	}


}
